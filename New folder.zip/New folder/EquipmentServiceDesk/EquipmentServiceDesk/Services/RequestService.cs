using EquipmentServiceDesk.Data;
using EquipmentServiceDesk.Models;
using EquipmentServiceDesk.Repositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EquipmentServiceDesk.Services
{
    public class RequestService
    {
        private readonly AppDbContext _context;
        private readonly IGenericRepository<Request> _repository;

        public RequestService(AppDbContext context, IGenericRepository<Request> repository)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));
        }

        public Task<List<Request>> GetAllAsync() => _repository.GetAllAsync();

        public async Task<List<Request>> GetAllWithDetailsAsync()
        {
            return await _context.Requests
                .AsNoTracking()
                .Include(r => r.User)
                .Include(r => r.Equipment)
                .ToListAsync();
        }

        public Task AddAsync(Request request) => _repository.AddAsync(request);

        /// <summary>
        /// Обновляем только саму заявку, не навигации (User/Equipment), чтобы EF не пытался обновлять граф.
        /// </summary>
        public async Task UpdateAsync(Request request)
        {
            var entity = await _context.Requests.FirstOrDefaultAsync(r => r.Id == request.Id);
            if (entity is null)
                return;

            entity.Title = request.Title;
            entity.Description = request.Description;
            entity.Status = request.Status;
            entity.EquipmentId = request.EquipmentId;

            await _context.SaveChangesAsync();
        }

        public async Task UpdateStatusAsync(int requestId, string newStatus)
        {
            var entity = await _context.Requests.FirstOrDefaultAsync(r => r.Id == requestId);
            if (entity is null)
                return;

            entity.Status = newStatus;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteByIdAsync(int id)
        {
            var entity = await _context.Requests.FirstOrDefaultAsync(r => r.Id == id);
            if (entity is null)
                return;

            _context.Requests.Remove(entity);
            await _context.SaveChangesAsync();
        }
    }
}
