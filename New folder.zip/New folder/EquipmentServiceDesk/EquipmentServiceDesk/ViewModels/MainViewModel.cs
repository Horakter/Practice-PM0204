﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using EquipmentServiceDesk.Models;
using EquipmentServiceDesk.Services;
using EquipmentServiceDesk.Views;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;


namespace EquipmentServiceDesk.ViewModels
{
    public partial class MainViewModel : ObservableObject
    {
        private User _currentUser;
        private readonly CurrentUserService _currentUserService;
        private readonly IServiceProvider _rootProvider;
        private readonly IServiceScopeFactory _scopeFactory;

        [ObservableProperty]
        private string welcomeText;

        public string Username => _currentUserService.CurrentUser?.Username ?? "";

        public MainViewModel(CurrentUserService currentUserService, IServiceProvider serviceProvider, IServiceScopeFactory scopeFactory)
        {
            _currentUserService = currentUserService;
            _rootProvider = serviceProvider ?? throw new ArgumentNullException(nameof(serviceProvider));
            _scopeFactory = scopeFactory ?? throw new ArgumentNullException(nameof(scopeFactory));
        }

        public void Initialize(User user)
        {
            _currentUser = user;
            WelcomeText = $"Добро пожаловать, {user.Username} ({user.Role})";
        }

        [RelayCommand]
        private async Task OpenRequests()
        {
            // Важно: RequestsView использует scoped зависимости (AppDbContext).
            // Поэтому создаём отдельный scope на время жизни окна и освобождаем его при закрытии.
            var scope = _scopeFactory.CreateScope();
            try
            {
                var window = scope.ServiceProvider.GetRequiredService<RequestsView>();
                window.Closed += (_, __) => scope.Dispose();
                await window.InitializeAsync(_currentUser);
                window.Show();
            }
            catch
            {
                scope.Dispose();
                throw;
            }
        }

        [RelayCommand]
        private void Logout()
        {
            var login = _rootProvider.GetRequiredService<Views.LoginView>();
            login.Show();

            Application.Current.Windows
                .OfType<Window>()
                .FirstOrDefault(w => w is MainWindow)
                ?.Close();
        }
    }
}
