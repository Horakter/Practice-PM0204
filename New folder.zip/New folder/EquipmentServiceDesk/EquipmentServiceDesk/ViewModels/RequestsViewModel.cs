using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using EquipmentServiceDesk.Data;
using EquipmentServiceDesk.Models;
using EquipmentServiceDesk.Services;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace EquipmentServiceDesk.ViewModels
{
    public partial class RequestsViewModel : ObservableObject
    {
        private readonly AppDbContext _context;
        private readonly RequestService _requestService;
        private User? _currentUser;

        public RequestsViewModel(AppDbContext context, RequestService requestService)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _requestService = requestService ?? throw new ArgumentNullException(nameof(requestService));

            Requests = new ObservableCollection<Request>();
            Equipments = new ObservableCollection<Equipment>();

            SelectedStatusFilter = "Все";
        }

        // ====== UI state ======

        [ObservableProperty]
        private ObservableCollection<Request> requests;

        [ObservableProperty]
        private Request? selectedRequest;

        [ObservableProperty]
        private string? newTitle;

        [ObservableProperty]
        private string? newDescription;

        [ObservableProperty]
        private ObservableCollection<Equipment> equipments;

        [ObservableProperty]
        private Equipment? selectedEquipment;

        [ObservableProperty]
        private string selectedStatusFilter;

        [ObservableProperty]
        private string? searchText;

        public IReadOnlyList<string> StatusFilters { get; } = new[] { "Все", "Новая", "В работе", "Завершена" };

        // Для ComboBox статуса в таблице (если понадобится)
        public IReadOnlyList<string> Statuses { get; } = new[] { "Новая", "В работе", "Завершена" };

        public async Task InitializeAsync(User user)
        {
            _currentUser = user ?? throw new ArgumentNullException(nameof(user));
            await LoadEquipmentsAsync();
            await LoadRequestsAsync();
        }

        private async Task LoadEquipmentsAsync()
        {
            // В твоём контексте DbSet называется Equipment (в единственном числе)
            var list = await _context.Equipment.AsNoTracking().ToListAsync();
            Equipments = new ObservableCollection<Equipment>(list);
            SelectedEquipment ??= Equipments.FirstOrDefault();
        }

        private async Task LoadRequestsAsync()
        {
            if (_currentUser is null)
                return;

            var list = await _requestService.GetAllWithDetailsAsync();

            // Права: обычный пользователь видит только свои заявки
            if (!string.Equals(_currentUser.Role, "Admin", StringComparison.OrdinalIgnoreCase))
            {
                list = list.Where(r => r.UserId == _currentUser.Id).ToList();
            }

            // Фильтр статуса
            if (!string.IsNullOrWhiteSpace(SelectedStatusFilter) && SelectedStatusFilter != "Все")
            {
                list = list.Where(r => r.Status == SelectedStatusFilter).ToList();
            }

            // Поиск
            if (!string.IsNullOrWhiteSpace(SearchText))
            {
                var q = SearchText.Trim().ToLowerInvariant();
                list = list.Where(r =>
                        (r.Title ?? "").ToLowerInvariant().Contains(q) ||
                        (r.Description ?? "").ToLowerInvariant().Contains(q) ||
                        (r.Equipment?.Name ?? "").ToLowerInvariant().Contains(q) ||
                        (r.User?.Username ?? "").ToLowerInvariant().Contains(q))
                    .ToList();
            }

            Requests = new ObservableCollection<Request>(list);
        }

        [RelayCommand]
        private Task ApplyFilter() => LoadRequestsAsync();

        [RelayCommand]
        private async Task ChangeStatus(string newStatus)
        {
            if (SelectedRequest is null)
                return;

            if (_currentUser is null)
                return;

            // Если нужно — ограничь права на смену статуса.
            // Сейчас: админ может менять любые, пользователь — только свои.
            if (!string.Equals(_currentUser.Role, "Admin", StringComparison.OrdinalIgnoreCase) && SelectedRequest.UserId != _currentUser.Id)
            {
                MessageBox.Show("Вы не можете менять статус чужой заявки.");
                return;
            }

            try
            {
                await _requestService.UpdateStatusAsync(SelectedRequest.Id, newStatus);
                await LoadRequestsAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось сменить статус.\n{ex.Message}");
            }
        }

        [RelayCommand]
        private async Task AddRequest()
        {
            if (_currentUser is null)
                return;

            if (string.IsNullOrWhiteSpace(NewTitle))
            {
                MessageBox.Show("Введите название заявки.");
                return;
            }

            if (SelectedEquipment is null)
            {
                MessageBox.Show("Выберите оборудование.");
                return;
            }

            try
            {
                var request = new Request
                {
                    Title = NewTitle.Trim(),
                    Description = NewDescription?.Trim(),
                    Status = "Новая",
                    CreatedAt = DateTime.Now,
                    UserId = _currentUser.Id,
                    EquipmentId = SelectedEquipment.Id
                };

                await _requestService.AddAsync(request);

                NewTitle = "";
                NewDescription = "";

                await LoadRequestsAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось добавить заявку.\n{ex.Message}");
            }
        }

        [RelayCommand]
        private async Task UpdateRequest()
        {
            if (SelectedRequest is null)
                return;

            if (_currentUser is null)
                return;

            if (!string.Equals(_currentUser.Role, "Admin", StringComparison.OrdinalIgnoreCase) && SelectedRequest.UserId != _currentUser.Id)
            {
                MessageBox.Show("Вы не можете редактировать чужую заявку.");
                return;
            }

            try
            {
                await _requestService.UpdateAsync(SelectedRequest);
                await LoadRequestsAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось обновить заявку.\n{ex.Message}");
            }
        }

        [RelayCommand]
        private async Task DeleteRequest()
        {
            if (SelectedRequest is null)
                return;

            if (_currentUser is null)
                return;

            if (!string.Equals(_currentUser.Role, "Admin", StringComparison.OrdinalIgnoreCase) && SelectedRequest.UserId != _currentUser.Id)
            {
                MessageBox.Show("Вы не можете удалить чужую заявку.");
                return;
            }

            if (MessageBox.Show("Удалить выбранную заявку?", "Подтверждение", MessageBoxButton.YesNo) != MessageBoxResult.Yes)
                return;

            try
            {
                await _requestService.DeleteByIdAsync(SelectedRequest.Id);
                await LoadRequestsAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось удалить заявку.\n{ex.Message}");
            }
        }

        [RelayCommand]
        private void Close()
        {
            Application.Current.Windows
                .OfType<Window>()
                .FirstOrDefault(w => w.GetType().Name == "RequestsView")
                ?.Close();
        }
    }
}
